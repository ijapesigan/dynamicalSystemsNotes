#' Add environment tokens here.
#'
#' tokens <- c(
#'   KEY1 = "VALUE1",
#'   KEY2 = "VALUE2"
#' )
#'
if (git_user == "ijapesigan") {
  tokens <- c(
    GITHUB_PAT = "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",
    DOCKER_HUB_ACCESS_TOKEN = "dckr_pat_qhw2hVVuFCs2UIymgHOsPvVzDyM",
    QUARTO_PUB_AUTH_TOKEN = "qpa_upJIL7psR9SABtayhdsNF6IOmK4gFyoIDE87itZfkiHbNNCuTlKRKN92zQBSbJyP"
  )
}
if (git_user == "jeksterslab") {
  tokens <- c(
    GITHUB_PAT = "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"
  )
}
if (git_user == "sigmaresearch100") {
  tokens <- c(
    GITHUB_PAT = "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"
  )
}
