library(testthat)
library(dynamicalSystemsNotes)

test_check("dynamicalSystemsNotes")
